#!/bin/sh
/opt/python-3.6/bin/python3 ./hw1_parse.py $1 $2 $3
