#!/bin/sh
/opt/python-3.6/bin/python3 ./hw2_tocnf.py $1 $2
