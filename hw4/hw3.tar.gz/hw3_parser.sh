#!/bin/sh
/opt/python-3.6/bin/python3 ./hw3_parser.py $1 $2 $3
