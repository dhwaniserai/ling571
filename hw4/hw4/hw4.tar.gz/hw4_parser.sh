#!/bin/sh
/opt/python-3.6/bin/python3 ./hw4_parser.py $1 $2 $3
