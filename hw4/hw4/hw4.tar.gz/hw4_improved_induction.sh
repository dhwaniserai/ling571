#!/bin/sh
/opt/python-3.6/bin/python3 ./pcfg_improved_train.py "$1" "$2"