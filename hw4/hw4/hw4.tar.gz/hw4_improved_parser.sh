#!/bin/sh
/Library/Frameworks/Python.framework/Versions/3.7/bin/python3.7 ./hw4_improved_parser.py $1 $2 $3