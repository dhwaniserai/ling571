#!/bin/sh
/opt/python-3.6/bin/python3 ./pcfg_train.py "$1" "$2"